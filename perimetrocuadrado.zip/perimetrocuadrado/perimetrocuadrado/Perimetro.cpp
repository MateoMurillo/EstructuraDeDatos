#include "StdAfx.h"
#include "Perimetro.h"


Perimetro::Perimetro(void)
{
}
int Perimetro::Get_lado()
{
	return lado;
}
int Perimetro::Get_perimetro()
{return perimetro;
}
void Perimetro::set_lado(int l)
{
	lado=l;
}
void Perimetro::set_perimetro(int p)
{
	perimetro=p;
}

int Perimetro::Calcular()
{
	perimetro=4*lado;
		return perimetro;
}