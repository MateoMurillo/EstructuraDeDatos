#pragma once
#include "Perimetro.h"
#include <iostream> //Manejo de interaccion
#include "msclr\marshal_cppstd.h" //Manejar texto
namespace perimetrocuadrado {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblLado;
	protected: 
	private: System::Windows::Forms::Label^  lblPerimetro;
	private: System::Windows::Forms::TextBox^  txtLado;
	private: System::Windows::Forms::TextBox^  txtPerimetro;
	private: System::Windows::Forms::Button^  btCalcular;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblLado = (gcnew System::Windows::Forms::Label());
			this->lblPerimetro = (gcnew System::Windows::Forms::Label());
			this->txtLado = (gcnew System::Windows::Forms::TextBox());
			this->txtPerimetro = (gcnew System::Windows::Forms::TextBox());
			this->btCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblLado
			// 
			this->lblLado->AutoSize = true;
			this->lblLado->Location = System::Drawing::Point(25, 39);
			this->lblLado->Name = L"lblLado";
			this->lblLado->Size = System::Drawing::Size(45, 20);
			this->lblLado->TabIndex = 0;
			this->lblLado->Text = L"Lado";
			// 
			// lblPerimetro
			// 
			this->lblPerimetro->AutoSize = true;
			this->lblPerimetro->Location = System::Drawing::Point(25, 99);
			this->lblPerimetro->Name = L"lblPerimetro";
			this->lblPerimetro->Size = System::Drawing::Size(77, 20);
			this->lblPerimetro->TabIndex = 1;
			this->lblPerimetro->Text = L"Perimetro";
			// 
			// txtLado
			// 
			this->txtLado->Location = System::Drawing::Point(122, 39);
			this->txtLado->Name = L"txtLado";
			this->txtLado->Size = System::Drawing::Size(120, 26);
			this->txtLado->TabIndex = 2;
			// 
			// txtPerimetro
			// 
			this->txtPerimetro->Location = System::Drawing::Point(122, 96);
			this->txtPerimetro->Name = L"txtPerimetro";
			this->txtPerimetro->Size = System::Drawing::Size(120, 26);
			this->txtPerimetro->TabIndex = 3;
			// 
			// btCalcular
			// 
			this->btCalcular->Location = System::Drawing::Point(55, 163);
			this->btCalcular->Name = L"btCalcular";
			this->btCalcular->Size = System::Drawing::Size(165, 45);
			this->btCalcular->TabIndex = 4;
			this->btCalcular->Text = L"Calcular";
			this->btCalcular->UseVisualStyleBackColor = true;
			this->btCalcular->Click += gcnew System::EventHandler(this, &Form1::btCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(9, 20);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(278, 244);
			this->Controls->Add(this->btCalcular);
			this->Controls->Add(this->txtPerimetro);
			this->Controls->Add(this->txtLado);
			this->Controls->Add(this->lblPerimetro);
			this->Controls->Add(this->lblLado);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
		 Perimetro  perimetrito; //Creando el objeto cuadradito
		 perimetrito.set_lado(System::Convert::ToInt32(txtLado->Text));
		 int perimetrofin;
		 perimetrofin = perimetrito.Calcular();
		 txtPerimetro->Text=System::Convert::ToString(perimetrofin);
			 }
};
}

