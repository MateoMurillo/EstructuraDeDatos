#pragma once
class Perimetro
{private: 
 int lado,perimetro;

public:
	Perimetro(void);
	int Get_lado();
	int Get_perimetro();
	void set_lado(int l);
	void set_perimetro(int p);
	int Calcular();
};

