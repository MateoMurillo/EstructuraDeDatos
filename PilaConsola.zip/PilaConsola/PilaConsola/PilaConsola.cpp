// PilaConsola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Pila.h"
#include <iostream>
#include "conio.h"

using namespace std;

void main()
{Pila pila;
int elem;
cout<<"Ingrese 10 datos"<<endl;
for(int i=0;i<10;i++)
{
 cin>>elem;
 pila.Apilar(elem);
 }
cout<<"----------MOSTRANDO PILA------------"<<endl;
for(int i=0;i<10;i++)
{   pila.verpila(i);}
cout<<"-----------MOSTRANDO TOPES----------"<<endl;
for(int i=0;i<10;i++)
 {  
	 cout<<"tope:"<<pila.gettope()<<endl;
	 pila.verpila(pila.gettope());
	 pila.Desapilar();
	 cout<<"tope eliminado"<<endl;
 }

	getch();
}

