#pragma once
#define MAX 10
class Pila
{private:
 int pila[MAX];
 int Tope;
public:
	Pila(void);
	~Pila(void);
	int gettope();
	bool Apilar(int elemento);
	bool PilaVacia();
	bool Desapilar();
	bool pilallena(int tope);
	void verpila(int pos);
};

