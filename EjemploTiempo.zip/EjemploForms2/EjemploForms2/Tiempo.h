#pragma once
ref class Tiempo
{private: //atributos
	int segundos;
	int horas; 
public: //metodos
	Tiempo(void);//constructor
	//metodos de acceso de los atributos
	int Get_segundos();
	int Get_horas();
	//darle valor a los atributos
	void Set_segundos(int s);
	void Set_horas(int h);
	//operaciones especificas
	int Calcular();
};

