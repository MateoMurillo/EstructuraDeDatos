#pragma once
#include "Tiempo.h"
#include <iostream>
#include "msclr\marshal_cppstd.h" //Manejar texto

namespace EjemploForms2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  LblSegundos;
	private: System::Windows::Forms::Label^  LblHora;
	protected: 

	protected: 

	protected: 


	private: System::Windows::Forms::TextBox^  TxtSegundos;
	private: System::Windows::Forms::TextBox^  TxtHoras;




	private: System::Windows::Forms::Button^  BtnCalcular;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->LblSegundos = (gcnew System::Windows::Forms::Label());
			this->LblHora = (gcnew System::Windows::Forms::Label());
			this->TxtSegundos = (gcnew System::Windows::Forms::TextBox());
			this->TxtHoras = (gcnew System::Windows::Forms::TextBox());
			this->BtnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// LblSegundos
			// 
			this->LblSegundos->AutoSize = true;
			this->LblSegundos->Location = System::Drawing::Point(25, 68);
			this->LblSegundos->Name = L"LblSegundos";
			this->LblSegundos->Size = System::Drawing::Size(55, 13);
			this->LblSegundos->TabIndex = 1;
			this->LblSegundos->Text = L"Segundos";
			// 
			// LblHora
			// 
			this->LblHora->AutoSize = true;
			this->LblHora->Location = System::Drawing::Point(25, 149);
			this->LblHora->Name = L"LblHora";
			this->LblHora->Size = System::Drawing::Size(35, 13);
			this->LblHora->TabIndex = 2;
			this->LblHora->Text = L"Horas";
			// 
			// TxtSegundos
			// 
			this->TxtSegundos->Location = System::Drawing::Point(117, 68);
			this->TxtSegundos->Name = L"TxtSegundos";
			this->TxtSegundos->Size = System::Drawing::Size(100, 20);
			this->TxtSegundos->TabIndex = 4;
			// 
			// TxtHoras
			// 
			this->TxtHoras->Location = System::Drawing::Point(117, 142);
			this->TxtHoras->Name = L"TxtHoras";
			this->TxtHoras->Size = System::Drawing::Size(100, 20);
			this->TxtHoras->TabIndex = 5;
			// 
			// BtnCalcular
			// 
			this->BtnCalcular->ForeColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(0)), static_cast<System::Int32>(static_cast<System::Byte>(0)), 
				static_cast<System::Int32>(static_cast<System::Byte>(64)));
			this->BtnCalcular->Location = System::Drawing::Point(98, 200);
			this->BtnCalcular->Name = L"BtnCalcular";
			this->BtnCalcular->Size = System::Drawing::Size(75, 23);
			this->BtnCalcular->TabIndex = 6;
			this->BtnCalcular->Text = L"Calcular";
			this->BtnCalcular->UseVisualStyleBackColor = true;
			this->BtnCalcular->Click += gcnew System::EventHandler(this, &Form1::BtnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->BtnCalcular);
			this->Controls->Add(this->TxtHoras);
			this->Controls->Add(this->TxtSegundos);
			this->Controls->Add(this->LblHora);
			this->Controls->Add(this->LblSegundos);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
private: System::Void BtnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 Tiempo tiempito;
			 tiempito.Set_segundos(System::Convert::ToInt32(TxtSegundos->Text));
			 int horasfin;
			 horasfin=tiempito.Calcular();
			 TxtHoras->Text=System::Convert::ToString(horasfin);
		 }

};
}

