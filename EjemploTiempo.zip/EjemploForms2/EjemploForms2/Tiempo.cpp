#include "StdAfx.h"
#include "Tiempo.h"


Tiempo::Tiempo(void)
{
}

//metodos de acceso de los atributos
	int Tiempo::Get_segundos()
	{
		return segundos;
	}
	int Tiempo::Get_horas()
	{
		return horas;
	}
	//darle valor a los atributos
	void Tiempo::Set_segundos(int s)
	{
		segundos=s;
	}
	void Tiempo::Set_horas(int h)
	{
		horas=h;
	}
	//operaciones especificas
	int Tiempo::Calcular()
	{
		horas=segundos/3600;
		return horas;
	}