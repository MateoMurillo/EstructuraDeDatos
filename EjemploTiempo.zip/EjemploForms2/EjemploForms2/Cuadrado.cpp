#include "StdAfx.h"
#include "Cuadrado.h"


Cuadrado::Cuadrado(void)
{
}

	//metodos de acceso de los atributos
	int Cuadrado::Get_lado()
	{
		return lado;
	}
	int Cuadrado::Get_area()
	{
		return area;
	}
	//darle valor a los atributos
	void Cuadrado::Set_lado(int l)
	{
		lado=l;
	}
	void Cuadrado::Set_area(int a)
	{
		area=a;
	}
	//operaciones especificas
	int Cuadrado::Calcular()
	{
		area=lado*lado;
		return area;
	}
