#pragma once

namespace HolaMundoForms {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  lblHolaMundo;
	private: System::Windows::Forms::TextBox^  TxtBxMensaje;

	private: System::Windows::Forms::Button^  btnMensaje;
	protected: 

	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->lblHolaMundo = (gcnew System::Windows::Forms::Label());
			this->TxtBxMensaje = (gcnew System::Windows::Forms::TextBox());
			this->btnMensaje = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// lblHolaMundo
			// 
			this->lblHolaMundo->AutoSize = true;
			this->lblHolaMundo->Location = System::Drawing::Point(94, 58);
			this->lblHolaMundo->Name = L"lblHolaMundo";
			this->lblHolaMundo->RightToLeft = System::Windows::Forms::RightToLeft::Yes;
			this->lblHolaMundo->Size = System::Drawing::Size(65, 13);
			this->lblHolaMundo->TabIndex = 0;
			this->lblHolaMundo->Text = L"Hola Mundo";
			this->lblHolaMundo->Click += gcnew System::EventHandler(this, &Form1::label1_Click);
			// 
			// TxtBxMensaje
			// 
			this->TxtBxMensaje->Location = System::Drawing::Point(75, 92);
			this->TxtBxMensaje->Name = L"TxtBxMensaje";
			this->TxtBxMensaje->Size = System::Drawing::Size(100, 20);
			this->TxtBxMensaje->TabIndex = 1;
			// 
			// btnMensaje
			// 
			this->btnMensaje->Location = System::Drawing::Point(94, 148);
			this->btnMensaje->Name = L"btnMensaje";
			this->btnMensaje->Size = System::Drawing::Size(75, 23);
			this->btnMensaje->TabIndex = 2;
			this->btnMensaje->Text = L"Mensaje";
			this->btnMensaje->UseVisualStyleBackColor = true;
			this->btnMensaje->Click += gcnew System::EventHandler(this, &Form1::btnMensaje_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->btnMensaje);
			this->Controls->Add(this->TxtBxMensaje);
			this->Controls->Add(this->lblHolaMundo);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
				 TxtBxMensaje->Text="Hola Mundo";                                                 //click en el label
			 }
	private: System::Void btnMensaje_Click(System::Object^  sender, System::EventArgs^  e) {
				 TxtBxMensaje->Text="Hola Mundo";                                                 //click en el button
			 }
	};
}

