// ColaConsola.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Circular.h"
#include <iostream>
#include "conio.h"

#define TAM 6

using namespace std;

void main()
{int v[TAM],cabeza=0,final=-1,elem;
Circular cola;
 
int cantidadEnCola = 0, elemento = 0;

  while (cantidadEnCola < TAM){
        cout << "Introduce un elemento para la cola: ";
        cin >> elemento;
        cola.Insertar(elemento);
        cantidadEnCola++;
    }
    cout << "Elemento eliminado [" << cola.Eliminar() << "]" << endl;
    cola.Mostrar();
 getch();
}

