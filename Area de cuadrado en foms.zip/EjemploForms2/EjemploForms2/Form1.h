#pragma once
#include "Cuadrado.h"
#include <iostream>
#include "msclr\marshal_cppstd.h" //Manejar texto

namespace EjemploForms2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;
	using namespace msclr;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  LblLado;
	protected: 

	protected: 

	private: System::Windows::Forms::Label^  LblArea;
	private: System::Windows::Forms::TextBox^  TxtLado;


	private: System::Windows::Forms::TextBox^  TxtArea;
	private: System::Windows::Forms::Button^  BtnCalcular;






	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->LblLado = (gcnew System::Windows::Forms::Label());
			this->LblArea = (gcnew System::Windows::Forms::Label());
			this->TxtLado = (gcnew System::Windows::Forms::TextBox());
			this->TxtArea = (gcnew System::Windows::Forms::TextBox());
			this->BtnCalcular = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// LblLado
			// 
			this->LblLado->AutoSize = true;
			this->LblLado->Location = System::Drawing::Point(25, 101);
			this->LblLado->Name = L"LblLado";
			this->LblLado->Size = System::Drawing::Size(31, 13);
			this->LblLado->TabIndex = 1;
			this->LblLado->Text = L"Lado";
			// 
			// LblArea
			// 
			this->LblArea->AutoSize = true;
			this->LblArea->Location = System::Drawing::Point(25, 149);
			this->LblArea->Name = L"LblArea";
			this->LblArea->Size = System::Drawing::Size(29, 13);
			this->LblArea->TabIndex = 2;
			this->LblArea->Text = L"Area";
			// 
			// TxtLado
			// 
			this->TxtLado->Location = System::Drawing::Point(117, 94);
			this->TxtLado->Name = L"TxtLado";
			this->TxtLado->Size = System::Drawing::Size(100, 20);
			this->TxtLado->TabIndex = 4;
			// 
			// TxtArea
			// 
			this->TxtArea->Location = System::Drawing::Point(117, 142);
			this->TxtArea->Name = L"TxtArea";
			this->TxtArea->Size = System::Drawing::Size(100, 20);
			this->TxtArea->TabIndex = 5;
			// 
			// BtnCalcular
			// 
			this->BtnCalcular->Location = System::Drawing::Point(98, 200);
			this->BtnCalcular->Name = L"BtnCalcular";
			this->BtnCalcular->Size = System::Drawing::Size(75, 23);
			this->BtnCalcular->TabIndex = 6;
			this->BtnCalcular->Text = L"Calcular";
			this->BtnCalcular->UseVisualStyleBackColor = true;
			this->BtnCalcular->Click += gcnew System::EventHandler(this, &Form1::BtnCalcular_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 261);
			this->Controls->Add(this->BtnCalcular);
			this->Controls->Add(this->TxtArea);
			this->Controls->Add(this->TxtLado);
			this->Controls->Add(this->LblArea);
			this->Controls->Add(this->LblLado);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	
private: System::Void BtnCalcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 Cuadrado cuadradito;
			 cuadradito.Set_lado(System::Convert::ToInt32(TxtLado->Text));
			 int areafin;
			 areafin=cuadradito.Calcular();
			 TxtArea->Text=System::Convert::ToString(areafin);
		 }
};
}

