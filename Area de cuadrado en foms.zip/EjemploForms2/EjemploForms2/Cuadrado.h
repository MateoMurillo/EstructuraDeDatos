#pragma once
ref class Cuadrado
{
private: //atributos
	int lado;
	int area; 
public: //metodos
	Cuadrado(void);//constructor
	//metodos de acceso de los atributos
	int Get_lado();
	int Get_area();
	//darle valor a los atributos
	void Set_lado(int l);
	void Set_area(int a);
	//operaciones especificas
	int Calcular();
};

