#include "StdAfx.h"
#include "Rectangulo.h"


Rectangulo::Rectangulo(void)
{
}


Rectangulo::~Rectangulo(void)
{
}
int Rectangulo::getArea()
{
	return(width*height);
}
