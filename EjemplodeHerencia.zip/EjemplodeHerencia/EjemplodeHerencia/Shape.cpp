#include "StdAfx.h"
#include "Shape.h"


Shape::Shape(void)
{
}


Shape::~Shape(void)
{
}
void Shape::setWidth(int w)
{
	width=w;
}
void Shape::setHeight(int h)
{
	height=h;
}