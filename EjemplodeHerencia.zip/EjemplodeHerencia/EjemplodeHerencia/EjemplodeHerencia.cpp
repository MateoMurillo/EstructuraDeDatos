// EjemplodeHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "Rectangulo.h"
#include <iostream>
using namespace std;

void main()
{
	Rectangulo rect;
	rect.setWidth(8);
	rect.setHeight(4);
	cout<<"total Area: "<<rect.getArea()<<endl;

	getch();
	
}

