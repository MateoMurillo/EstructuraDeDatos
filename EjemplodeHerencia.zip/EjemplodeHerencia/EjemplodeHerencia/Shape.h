#pragma once
//Base Class
class Shape
{protected://atributos
 int width;
 int height;
public://metodos
	Shape(void);
	~Shape(void);
	void setWidth(int w);
	void setHeight(int h);
};

